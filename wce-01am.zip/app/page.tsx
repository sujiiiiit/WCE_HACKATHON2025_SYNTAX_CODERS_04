"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Maps from "@/components/map";
import { Input } from "@/components/ui/input";
import Image from "next/image";
import MessageContainer from "@/components/chat/messageContainer";
import { APIProvider } from "@vis.gl/react-google-maps";

const tabLabels = ["Map", "Explore", "Saved"];

const tabContents = [
  <Maps key="maps" />,
  <div
    key="explore"
    className="w-full h-full bg-gray-100 flex items-center justify-center"
  >
    <h2 className="text-2xl font-semibold">Explore Content</h2>
  </div>,
  <div
    key="saved"
    className="w-full h-full bg-gray-100 flex items-center justify-center"
  >
    <h2 className="text-2xl font-semibold">Saved Places</h2>
  </div>,
];

const variants = {
  initial: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
  }),
  animate: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.5, ease: "easeInOut" },
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -300 : 300,
    opacity: 0,
    transition: { duration: 0.5, ease: "easeInOut" },
  }),
};

const MapComponent = () => {
  const [activeTab, setActiveTab] = useState(0);
  // Determine slide direction based on tab index change
  const [direction, setDirection] = useState(0);

  const handleTabChange = (index: number): void => {
    if (index === activeTab) return;
    setDirection(index > activeTab ? 1 : -1);
    setActiveTab(index);
  };

  return (
    <main className="relative flex h-dvh w-dvw overflow-hidden">
      {/* Floating Tabs - centered at top */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-40 flex items-center bg-white/80 backdrop-blur-md rounded-full shadow-md px-1 py-1">
        {tabLabels.map((tab, index) => (
          <motion.button
            key={index}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`px-4 py-2 text-sm font-medium rounded-full transition-colors duration-200 mx-1 ${
              activeTab === index
                ? "bg-primary text-white"
                : "text-gray-600 hover:bg-gray-100"
            }`}
            onClick={() => handleTabChange(index)}
          >
            {tab}
          </motion.button>
        ))}
      </div>

      {/* Tab Content Container - with enhanced sliding animations */}
      <div className="w-full h-full relative overflow-hidden">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={activeTab}
            custom={direction}
            variants={variants}
            initial="initial"
            animate="animate"
            exit="exit"
            className="absolute inset-0 w-full h-full"
          >
            <APIProvider
              apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY as string}
              region="IN"
            >
              {tabContents[activeTab]}
            </APIProvider>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Message container - stays fixed */}
      <div className="absolute bottom-0 left-0 right-0 bg-transparent z-30">
        <MessageContainer className="" />
      </div>
    </main>
  );
};

export default MapComponent;
