(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_6d1387._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_6d1387._.js",
  "chunks": [
    "static/chunks/_386340._.js",
    "static/chunks/node_modules_motion_dist_es_5364d5._.js",
    "static/chunks/node_modules_68085f._.js"
  ],
  "source": "dynamic"
});
