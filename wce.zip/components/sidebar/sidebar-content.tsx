
export function SidebarContent() {

  return (
   <p>Sidebar content here</p>
  )
}

