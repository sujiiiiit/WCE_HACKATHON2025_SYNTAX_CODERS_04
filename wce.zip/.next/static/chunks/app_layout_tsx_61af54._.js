(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/node_modules_framer-motion_dist_es_c46283._.js",
    "static/chunks/node_modules_c73b01._.js",
    "static/chunks/_eb6063._.js",
    "static/chunks/_872e35._.css",
    "static/chunks/components_sidebar_sidebar-content_tsx_78016f._.js"
  ],
  "source": "dynamic"
});
