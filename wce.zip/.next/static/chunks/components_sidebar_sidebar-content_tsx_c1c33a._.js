(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/components_sidebar_sidebar-content_tsx_c1c33a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/components_sidebar_sidebar-content_tsx_c1c33a._.js",
  "chunks": [
    "static/chunks/components_sidebar_sidebar-content_tsx_7f379f._.js"
  ],
  "source": "dynamic"
});
