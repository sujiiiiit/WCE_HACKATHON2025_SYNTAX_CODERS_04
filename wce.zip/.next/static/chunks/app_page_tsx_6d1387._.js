(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_6d1387._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_6d1387._.js",
  "chunks": [
    "static/chunks/_435c28._.js",
    "static/chunks/node_modules_motion_dist_es_5364d5._.js",
    "static/chunks/node_modules_micromark-core-commonmark_dev_lib_a91d55._.js",
    "static/chunks/node_modules_5893b3._.js"
  ],
  "source": "dynamic"
});
